package com.test;

import org.springframework.beans.factory.BeanNameAware;


public class Triangle implements BeanNameAware
{
		public void draw()
          {
        	  System.out.println("Triangle draw" );
          }

		
		public void init() {
           System.out.println("Init method called");			
		}

		
		public void destroy() {
		     System.out.println("Destory method called");
			
		}


		@Override
		public void setBeanName(String arg0) {
            System.out.println("Bean name aware"+" "+arg0);			
		}
		
		


}
